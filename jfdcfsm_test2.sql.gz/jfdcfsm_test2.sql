--
-- Database: `jfdcfsm_test2`
--

-- --------------------------------------------------------

--
-- Table structure for table `gmp_packing_preop_corrective_actions`
--

CREATE TABLE `gmp_packing_preop_corrective_actions` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` char(3) NOT NULL,
  `name` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gmp_packing_preop_corrective_actions`
--

INSERT INTO `gmp_packing_preop_corrective_actions` (`id`, `code`, `name`) VALUES
(1, 'N/A', 'None'),
(2, 'RC', 'Re-cleaned'),
(3, 'WRS', 'Wash/Rinse/Sanitize');

-- --------------------------------------------------------

--
-- Table structure for table `gmp_packing_preop_items_log`
--

CREATE TABLE `gmp_packing_preop_items_log` (
  `id` int(10) UNSIGNED NOT NULL,
  `item_id` int(10) UNSIGNED NOT NULL,
  `is_acceptable` tinyint(4) NOT NULL,
  `corrective_action_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `gmp_packing_preop_log`
--

CREATE TABLE `gmp_packing_preop_log` (
  `id` int(10) UNSIGNED NOT NULL,
  `capture_date_id` int(10) UNSIGNED NOT NULL,
  `preop_item_log_id` int(10) UNSIGNED NOT NULL,
  `time` time NOT NULL,
  `notes` varchar(64) NOT NULL,
  `person_performing_sanitation` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(10) UNSIGNED NOT NULL,
  `area_id` int(10) UNSIGNED NOT NULL,
  `type_id` int(10) UNSIGNED NOT NULL,
  `is_active` tinyint(4) NOT NULL,
  `position` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `area_id`, `type_id`, `is_active`, `position`, `name`) VALUES
(1, 1, 2, 1, 1, 'Floors'),
(2, 1, 2, 1, 2, 'Ceiling Lights'),
(3, 1, 2, 1, 3, 'Trash Recepticales'),
(4, 1, 2, 1, 4, 'Equipment Tomatoes'),
(5, 1, 2, 1, 5, 'Stainless Table (5)'),
(6, 1, 2, 1, 6, 'Roll Up Loading Doors'),
(7, 1, 2, 1, 7, 'Forklift/Palletjack/Wave'),
(8, 2, 2, 1, 1, 'Floors'),
(9, 2, 2, 1, 2, 'Cool Care Fans'),
(10, 2, 2, 1, 3, 'Ceiling Lights'),
(11, 2, 2, 1, 4, 'Trash Recepticales'),
(12, 2, 2, 1, 5, 'Walls'),
(13, 2, 2, 1, 6, 'Plastic Curtains'),
(14, 2, 2, 1, 7, 'Cooling Units'),
(15, 3, 2, 1, 1, 'Floors'),
(16, 3, 2, 1, 2, 'Ceiling Lights'),
(17, 3, 2, 1, 3, 'Trash Recepticales'),
(18, 3, 2, 1, 4, 'Walls'),
(19, 3, 2, 1, 5, 'Plastic Curtains'),
(20, 3, 2, 1, 6, 'Cooling Units');

-- --------------------------------------------------------

--
-- Table structure for table `item_types`
--

CREATE TABLE `item_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `item_types`
--

INSERT INTO `item_types` (`id`, `name`) VALUES
(1, 'Food Contact - Daily'),
(2, 'Non Food Contact - Daily');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) UNSIGNED NOT NULL COMMENT 'The unique identifier number for each table item',
  `module_id` int(11) UNSIGNED NOT NULL COMMENT 'The identifier for the moduel this log belongs to',
  `name` varchar(64) NOT NULL COMMENT 'The name of the log'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `module_id`, `name`) VALUES
(1, 10, 'Pre-Operational Inspection');

-- --------------------------------------------------------

--
-- Table structure for table `log_capture_dates`
--

CREATE TABLE `log_capture_dates` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE `modules` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'The unique identifier for each table element',
  `program_id` int(10) UNSIGNED NOT NULL COMMENT 'ID of the program to which this element is associated',
  `name` varchar(64) NOT NULL COMMENT 'The name of the module'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='The modules in which of each program is divided';

--
-- Dumping data for table `modules`
--

INSERT INTO `modules` (`id`, `program_id`, `name`) VALUES
(1, 1, 'Introduction'),
(2, 1, 'Preventive Maintenance and Mobile Maintenance Program'),
(3, 1, 'Personnel Hygiene'),
(4, 1, 'Facility Sanitation'),
(5, 1, 'Pest Control'),
(6, 1, 'Training Employee/Vendor and Visitor'),
(7, 1, 'Regulatory and Internal Audit'),
(8, 1, 'Trace Back and Recall Program'),
(9, 1, 'Requirements Program'),
(10, 1, 'Packing'),
(11, 1, 'Suppliers'),
(12, 1, 'Biosecurity'),
(13, 1, 'HACCP');

-- --------------------------------------------------------

--
-- Table structure for table `privileges`
--

CREATE TABLE `privileges` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'The unique identifier for each table element',
  `name` varchar(5) NOT NULL COMMENT 'The name of the privilege'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='The user system privileges';

--
-- Dumping data for table `privileges`
--

INSERT INTO `privileges` (`id`, `name`) VALUES
(1, 'None'),
(2, 'Read'),
(3, 'Write');

-- --------------------------------------------------------

--
-- Table structure for table `programs`
--

CREATE TABLE `programs` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'The unique identifier for each table element',
  `name` char(3) NOT NULL COMMENT 'The name for each procedure'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Company-especific certification program procedures';

--
-- Dumping data for table `programs`
--

INSERT INTO `programs` (`id`, `name`) VALUES
(2, 'GAP'),
(1, 'GMP');

-- --------------------------------------------------------

--
-- Table structure for table `recovery_tokens`
--

CREATE TABLE `recovery_tokens` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'The unique identifier for each table element',
  `user_id` int(10) UNSIGNED NOT NULL COMMENT 'ID of the user to which the token is associated',
  `expiration_date` datetime NOT NULL COMMENT 'Timestamp for when the token was issued',
  `token` char(128) NOT NULL COMMENT 'The unique password recovery token'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Password recovery tokens requested by users';

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'The unique identifier for each table element',
  `name` varchar(13) NOT NULL COMMENT 'The name of the user role'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='The roles that users can have in the system';

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`) VALUES
(1, 'Administrator'),
(2, 'Director'),
(4, 'Employee'),
(3, 'Supervisor');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'The unique identifier for each table element',
  `is_active` tinyint(3) UNSIGNED NOT NULL COMMENT 'Flag that indicates if the user account can be used',
  `role_id` int(10) UNSIGNED NOT NULL COMMENT 'ID of the role for this user',
  `zone_id` int(10) UNSIGNED NOT NULL COMMENT 'The identifier of the zone the user belongs to',
  `employee_num` int(10) UNSIGNED NOT NULL COMMENT 'The company-especific unique ID number for each user',
  `first_name` varchar(32) NOT NULL COMMENT 'The user''s first name(s)',
  `last_name` varchar(32) NOT NULL COMMENT 'The user''s last name(s)',
  `email` varchar(32) NOT NULL COMMENT 'The user''s (probably company-especific) e-mail for account administration',
  `login_name` varchar(16) NOT NULL COMMENT 'The user''s account nickname',
  `login_password` char(60) NOT NULL COMMENT 'The user''s password for logging in to his account'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='The users'' account profile information';

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `is_active`, `role_id`, `zone_id`, `employee_num`, `first_name`, `last_name`, `email`, `login_name`, `login_password`) VALUES
(1, 1, 1, 1, 1, 'Administrador', 'de Prueba', 'caom92@live.com', 'administrador', '$2y$10$7.ydTeabG5emDKgbHI62QuxpflbZovQJXFET40mhc3lR3iqA/Bz2K'),
(2, 1, 2, 1, 2, 'Director', 'de Prueba', 'caom92@live.com', 'director', '$2y$10$9GzcttktIMg9JFFXyMiIZOYLaiE2yRE5Ag/Xgn7Z98nsIpb4yNI5K'),
(3, 1, 3, 5, 3, 'Supervisor', 'I', 'caom92@live.com', 'supervisor1', '$2y$10$9GzcttktIMg9JFFXyMiIZOYLaiE2yRE5Ag/Xgn7Z98nsIpb4yNI5K'),
(4, 1, 3, 1, 4, 'Supervisor', 'II', 'caom92@live.com', 'supervisor2', '$2y$10$9GzcttktIMg9JFFXyMiIZOYLaiE2yRE5Ag/Xgn7Z98nsIpb4yNI5K'),
(5, 1, 4, 5, 5, 'Empleado', 'I', 'victor.miracle@uabc.edu.mx', 'empleado1', '$2y$10$ARpd7fNWWgHvYfScJ8HLIuBzRDGus1lWV6Oj5LfoTjyIIs6QJuNXu');

-- --------------------------------------------------------

--
-- Table structure for table `users_logs_privileges`
--

CREATE TABLE `users_logs_privileges` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'The unique identifier number for each table item',
  `user_id` int(10) UNSIGNED NOT NULL COMMENT 'The identifier for the user that owns this privilege',
  `log_id` int(10) UNSIGNED NOT NULL COMMENT 'The identifier of the log to which the user has this privilege',
  `privilege_id` int(10) UNSIGNED NOT NULL COMMENT 'The identifier of the privilege that the user has for this log'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_logs_privileges`
--

INSERT INTO `users_logs_privileges` (`id`, `user_id`, `log_id`, `privilege_id`) VALUES
(1, 3, 1, 2),
(2, 4, 1, 2),
(3, 5, 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `working_areas`
--

CREATE TABLE `working_areas` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'The unique identifier number for each table item',
  `zone_id` int(10) UNSIGNED NOT NULL COMMENT 'The identifier of the zone which this area belongs to',
  `name` varchar(64) NOT NULL COMMENT 'The name of the area'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `working_areas`
--

INSERT INTO `working_areas` (`id`, `zone_id`, `name`) VALUES
(1, 5, 'Warehouse'),
(2, 5, 'Cooler #1'),
(3, 5, 'Cooler #2'),
(4, 5, 'Cooler #3'),
(5, 5, 'Cooler #4'),
(6, 5, 'Packaging Room #5'),
(7, 5, 'Warehouse Annex'),
(8, 5, 'Department 1 & 2'),
(9, 5, 'Cooler #6'),
(10, 5, 'Packaging Room #7'),
(11, 5, 'Women Restroom #1'),
(12, 5, 'Women Restroom #2'),
(13, 5, 'Break Area'),
(14, 5, 'Men Restroom'),
(15, 5, 'Women Restroom');

-- --------------------------------------------------------

--
-- Table structure for table `zones`
--

CREATE TABLE `zones` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'The unique identifier for each table element',
  `name` char(3) NOT NULL COMMENT 'The name for each zone element'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Company-especific (geographical or logical) zones';

--
-- Dumping data for table `zones`
--

INSERT INTO `zones` (`id`, `name`) VALUES
(1, 'AVA'),
(2, 'BCN'),
(3, 'HMO'),
(4, 'HTO'),
(5, 'LAW'),
(6, 'MUL'),
(7, 'SGO'),
(8, 'SJD'),
(9, 'SLG'),
(10, 'SON'),
(11, 'SSF'),
(12, 'TEP'),
(13, 'TOR'),
(14, 'ZAR'),
(15, 'ZIH');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gmp_packing_preop_corrective_actions`
--
ALTER TABLE `gmp_packing_preop_corrective_actions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gmp_packing_preop_items_log`
--
ALTER TABLE `gmp_packing_preop_items_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item_id` (`item_id`),
  ADD KEY `corrective_action_id` (`corrective_action_id`);

--
-- Indexes for table `gmp_packing_preop_log`
--
ALTER TABLE `gmp_packing_preop_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `capture_date_id` (`capture_date_id`),
  ADD KEY `preop_item_log_id` (`preop_item_log_id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `type_id` (`type_id`),
  ADD KEY `area_id` (`area_id`);

--
-- Indexes for table `item_types`
--
ALTER TABLE `item_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `module_id` (`module_id`);

--
-- Indexes for table `log_capture_dates`
--
ALTER TABLE `log_capture_dates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `program_id` (`program_id`);

--
-- Indexes for table `privileges`
--
ALTER TABLE `privileges`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `programs`
--
ALTER TABLE `programs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `recovery_tokens`
--
ALTER TABLE `recovery_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `employee_num` (`employee_num`,`email`,`login_name`),
  ADD KEY `role_id` (`role_id`),
  ADD KEY `zone_id` (`zone_id`);

--
-- Indexes for table `users_logs_privileges`
--
ALTER TABLE `users_logs_privileges`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `log_id` (`log_id`),
  ADD KEY `privilege_id` (`privilege_id`);

--
-- Indexes for table `working_areas`
--
ALTER TABLE `working_areas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `zone_id` (`zone_id`);

--
-- Indexes for table `zones`
--
ALTER TABLE `zones`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gmp_packing_preop_corrective_actions`
--
ALTER TABLE `gmp_packing_preop_corrective_actions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `gmp_packing_preop_items_log`
--
ALTER TABLE `gmp_packing_preop_items_log`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gmp_packing_preop_log`
--
ALTER TABLE `gmp_packing_preop_log`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `item_types`
--
ALTER TABLE `item_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'The unique identifier number for each table item', AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `log_capture_dates`
--
ALTER TABLE `log_capture_dates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `modules`
--
ALTER TABLE `modules`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'The unique identifier for each table element', AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `privileges`
--
ALTER TABLE `privileges`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'The unique identifier for each table element', AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `programs`
--
ALTER TABLE `programs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'The unique identifier for each table element', AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `recovery_tokens`
--
ALTER TABLE `recovery_tokens`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'The unique identifier for each table element', AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'The unique identifier for each table element', AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'The unique identifier for each table element', AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `users_logs_privileges`
--
ALTER TABLE `users_logs_privileges`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'The unique identifier number for each table item', AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `working_areas`
--
ALTER TABLE `working_areas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'The unique identifier number for each table item', AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `zones`
--
ALTER TABLE `zones`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'The unique identifier for each table element', AUTO_INCREMENT=18;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `gmp_packing_preop_items_log`
--
ALTER TABLE `gmp_packing_preop_items_log`
  ADD CONSTRAINT `gmp_packing_preop_items` FOREIGN KEY (`corrective_action_id`) REFERENCES `gmp_packing_preop_corrective_actions` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `gmp_packing_preop_items_item_id` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `gmp_packing_preop_log`
--
ALTER TABLE `gmp_packing_preop_log`
  ADD CONSTRAINT `gmp_packing_preop_log_capture_date_id` FOREIGN KEY (`capture_date_id`) REFERENCES `log_capture_dates` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `gmp_packing_preop_log_item_log_id` FOREIGN KEY (`preop_item_log_id`) REFERENCES `gmp_packing_preop_items_log` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `items_area_id` FOREIGN KEY (`area_id`) REFERENCES `working_areas` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `items_type_id` FOREIGN KEY (`type_id`) REFERENCES `item_types` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `logs`
--
ALTER TABLE `logs`
  ADD CONSTRAINT `logs_module_id` FOREIGN KEY (`module_id`) REFERENCES `modules` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `log_capture_dates`
--
ALTER TABLE `log_capture_dates`
  ADD CONSTRAINT `log_capture_dates_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `modules`
--
ALTER TABLE `modules`
  ADD CONSTRAINT `modules_program_id` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `recovery_tokens`
--
ALTER TABLE `recovery_tokens`
  ADD CONSTRAINT `recovery_tokens_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_role_id` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `users_zone_id` FOREIGN KEY (`zone_id`) REFERENCES `zones` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `users_logs_privileges`
--
ALTER TABLE `users_logs_privileges`
  ADD CONSTRAINT `users_logs_privileges_log_id` FOREIGN KEY (`log_id`) REFERENCES `logs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `users_logs_privileges_log_privilege_id` FOREIGN KEY (`privilege_id`) REFERENCES `privileges` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `users_logs_privileges_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `working_areas`
--
ALTER TABLE `working_areas`
  ADD CONSTRAINT `working_areas_zone_id` FOREIGN KEY (`zone_id`) REFERENCES `zones` (`id`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
